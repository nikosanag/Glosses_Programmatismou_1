public class TreeNode {
    int number; 
    int important;
    TreeNode left; 
    TreeNode right; 


    public TreeNode(int num){
        number = num; 
        left = null;
        right = null; 
    }
}
